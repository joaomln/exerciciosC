﻿int numero = 0;

for (int i = 1; i <= 1000; i++ )
{
    Console.WriteLine($"{numero} + {i} =  {numero = numero + i}");

}

Console.WriteLine(numero); 