﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Digite o valor de sua nota fiscal");

double valorNota = Convert.ToDouble(Console.ReadLine());



if (valorNota <= 999)
{
    Console.WriteLine($"O valor de seu imposto é de {(valorNota / 100) * 2} com taxa de imposto de 2%");
} else if (valorNota > 999 && valorNota <=2999 )
{
    Console.WriteLine($"O valor de seu imposto é de {(valorNota / 100) * 2.5} com taxa de imposto de 2.5%");
}else if (valorNota > 2999 && valorNota <= 6999)
{
    Console.WriteLine($"O valor de seu imposto é de {(valorNota / 100) * 2.8} com taxa de imposto de 2.8%");
} else
{
    Console.WriteLine($"O valor de seu imposto é de {(valorNota / 100) * 3} com taxa de imposto de 3% ");
}
