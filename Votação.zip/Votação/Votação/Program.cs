﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Digite a idade");
int idade = Convert.ToInt32(Console.ReadLine());


Console.WriteLine("Você é brasileiro? (1 - S/2 - N)");
int opcao = Convert.ToInt32( Console.ReadLine());



bool nacionalidade = true;

if (opcao == 1)
{
   nacionalidade = true;
} else if (opcao == 2) 
{
    nacionalidade = false;
} 



if(nacionalidade && idade >= 16)
{
    Console.WriteLine("Você pode votar!");
} else if (nacionalidade && idade < 16)
{
    Console.WriteLine("Você Não tem idade para votar");
} else if (!nacionalidade && idade >= 16)
{
    Console.WriteLine("Você não pode votar pois não é brasileiro");
} else
{
    Console.WriteLine("Você não pode votar");
}
